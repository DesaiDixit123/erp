  <link rel="icon" href="<?php echo e(asset('img/core-img/favicon.ico')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/animate.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style.css')); ?>">



<!-- Preloader -->
<div id="preloader">
    <div class="scene">
        <div class="cube-wrapper">
            <div class="cube">
                <div class="cube-faces">
                    <div class="cube-face shadow"></div>
                    <div class="cube-face bottom"></div>
                    <div class="cube-face top"></div>
                    <div class="cube-face left"></div>
                    <div class="cube-face right"></div>
                    <div class="cube-face back"></div>
                    <div class="cube-face front"></div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /Preloader -->

<!-- Page Wrapper Start -->
<div class="flapt-page-wrapper">
  <!-- Sidebar -->
  <div class="flapt-sidemenu-wrapper">
    <!--  -->
    <?php echo $__env->make('layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  </div>

  <!-- Page Content -->
  <div class="flapt-page-content">
    <?php echo $__env->make('layouts.topbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php if(session('success')): ?>
    <div class="toast-container position-fixed top-0 end-0 p-3" style="z-index: 9999;">
      <div class="toast align-items-center text-bg-success border-0 show" role="alert">
      <div class="d-flex">
        <div class="toast-body">
        <?php echo e(session('success')); ?>

        </div>
        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
      </div>
      </div>
    </div>
  <?php endif; ?>

    <?php if($errors->any()): ?>
    <div class="toast-container position-fixed top-0 end-0 p-3" style="z-index: 9999;">
      <div class="toast align-items-center text-bg-danger border-0 show" role="alert">
      <div class="d-flex">
        <div class="toast-body">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php echo e($error); ?><br>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
      </div>
      </div>
    </div>
  <?php endif; ?>

    <!-- Main Content -->
    <div class="main-content">
      <div class="content-wraper-area">
        <div class="container-fluid">
          <div class="row g-4">
            <div class="col-12">
              <div class="card shadow-sm border-0">
                <div class="card-body py-4 px-4">
                  <div class="d-flex flex-column flex-md-row align-items-md-center justify-content-between">
                    <div class="mb-2 mb-md-0">
                      <h4 class="mb-1 text-primary fw-semibold">
                        Edit <?php echo e($employee->user_type == 'Admin' ? 'Admin' : 'Operator'); ?>

                      </h4>
                      <p class="text-muted mb-0">Update the <?php echo e($employee->user_type); ?> details below</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="d-flex justify-content-center align-items-center min-vh-100 bg-light">
              <div class="col-md-10">
                <div class="card shadow">
                  <div class="card-body">
                    <div class="text-center mb-4">
                      <h4 class="card-title">Edit <?php echo e($employee->user_type); ?></h4>
                    </div>

                    <form action="<?php echo e(route('add-employee.update', $employee->id)); ?>" method="POST"
                      enctype="multipart/form-data">
                      <?php echo csrf_field(); ?>
                      <?php echo method_field('PUT'); ?>


                      <div class="row mb-3">
                        <div class="col-md-6">
                          <label for="name" class="form-label">Name*</label>
                          <input type="text" class="form-control" name="name" id="name" value="<?php echo e($employee->name); ?>"
                            required>
                        </div>
                        <div class="col-md-6">
                          <label for="email" class="form-label">Email*</label>
                          <input type="email" class="form-control" name="email" id="email"
                            value="<?php echo e($employee->email); ?>" required>
                        </div>
                      </div>

                      <div class="mb-3">
                        <label for="phone" class="form-label">Phone Number*</label>
                        <input type="text" class="form-control" name="phone" id="phone" value="<?php echo e($employee->phone); ?>"
                          required maxlength="10" pattern="\d{10}" title="Enter 10 digit number">
                      </div>

                      <div class="mb-3">
                        <label for="address" class="form-label">Address</label>
                        <textarea class="form-control" name="address" id="address"
                          rows="2"><?php echo e($employee->address); ?></textarea>
                      </div>

                      <!-- Password Fields in One Row -->
                      <div class="row mb-3">
                        <div class="col-md-6">
                          <label for="password" class="form-label">New Password (Optional)</label>
                          <input type="password" name="password" class="form-control">
                        </div>
                        <div class="col-md-6">
                          <label for="password_confirmation" class="form-label">Confirm Password</label>
                          <input type="password" name="password_confirmation" class="form-control">
                          <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                      </div>

                      <div class="mb-3">
                        <label for="user_type" class="form-label">User Type*</label>
                        <select name="user_type" id="user_type" class="form-control" required>
                          <option value="Admin" <?php echo e($employee->user_type === 'Admin' ? 'selected' : ''); ?>>Admin</option>
                          <option value="Operator" <?php echo e($employee->user_type === 'Operator' ? 'selected' : ''); ?>>Operator
                          </option>
                        </select>
                      </div>

                      <!-- Upload Fields in One Row -->
                      <div class="row mb-4">
                        <div class="col-md-6">
                          <label for="adhar_image" class="form-label">Upload Adhar Image</label>
                          <input type="file" class="form-control" name="adhar_image" id="adhar_image" accept="image/*">
                          <?php if($employee->adhar_image): ?>
                <img src="<?php echo e(asset('storage/' . $employee->adhar_image)); ?>"   alt="Adhar Image"
                class="img-thumbnail mt-2" width="120">
              <?php endif; ?>
                        </div>
                        <div class="col-md-6">
                          <label for="pan_image" class="form-label">Upload Pan Card</label>
                          <input type="file" class="form-control" name="pan_image" id="pan_image" accept="image/*">
                          <?php if($employee->pan_image): ?>
                <img src="<?php echo e(asset('storage/' . $employee->pan_image)); ?>" alt="Pan Image"
                class="img-thumbnail mt-2" width="120">
              <?php endif; ?>
                        </div>
                      </div>

                      <div class="d-grid">
                        <button type="submit" class="btn btn-primary">Update</button>
                      </div>

                    </form>
                  </div>
                </div>
              </div>
            </div>


          </div>
        </div>
      </div>

    </div>
  </div>
</div>
<script src="<?php echo e(asset('js/jquery.min.js')); ?>"> </script>
<script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"> </script>
<script src="<?php echo e(asset('js/default-assets/setting.js')); ?>"> </script>
<script src="<?php echo e(asset('js/default-assets/scrool-bar.js')); ?>"> </script>
<script src="<?php echo e(asset('js/todo-list.js')); ?>"> </script>
<script src="<?php echo e(asset('js/default-assets/active.js')); ?>"> </script>
<script src="<?php echo e(asset('js/apexcharts.min.js')); ?>"> </script>
<script src="<?php echo e(asset('js/dashboard-custom-sass.js')); ?>"> </script>

<!-- Auto-hide toast -->
<script>
  setTimeout(() => {
    document.querySelectorAll('.toast').forEach(toast => {
      toast.classList.remove('show');
    });
  }, 4000);
</script>
<?php echo $__env->make('layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\industry\resources\views/Employees/EditAdmin.blade.php ENDPATH**/ ?>