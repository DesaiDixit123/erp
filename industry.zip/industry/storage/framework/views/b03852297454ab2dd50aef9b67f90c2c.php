<link rel="icon" href="<?php echo e(asset('img/core-img/favicon.ico')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/animate.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('style.css')); ?>">

<div id="preloader">
    <div class="scene">
        <div class="cube-wrapper">
            <div class="cube">
                <div class="cube-faces">
                    <div class="cube-face shadow"></div>
                    <div class="cube-face bottom"></div>
                    <div class="cube-face top"></div>
                    <div class="cube-face left"></div>
                    <div class="cube-face right"></div>
                    <div class="cube-face back"></div>
                    <div class="cube-face front"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="flapt-page-wrapper">
    <div class="flapt-sidemenu-wrapper">
        <?php echo $__env->make('layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    <div class="flapt-page-content">
        <?php echo $__env->make('layouts.topbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php if(session('success')): ?>
            <div class="toast-container position-fixed top-0 end-0 p-3" style="z-index: 9999;">
                <div class="toast align-items-center text-bg-success border-0 show" role="alert">
                    <div class="d-flex">
                        <div class="toast-body">
                            <?php echo e(session('success')); ?>

                        </div>
                        <button type="button" class="btn-close btn-close-white me-2 m-auto"
                            data-bs-dismiss="toast"></button>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="toast-container position-fixed top-0 end-0 p-3" style="z-index: 9999;">
                <div class="toast align-items-center text-bg-danger border-0 show" role="alert">
                    <div class="d-flex">
                        <div class="toast-body">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($error); ?><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <button type="button" class="btn-close btn-close-white me-2 m-auto"
                            data-bs-dismiss="toast"></button>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <div class="main-content">
            <div class="content-wraper-area">
                <div class="container-fluid">
                    <div class="row g-4">
                        <div class="col-12">
                            <div class="card shadow-sm border-0">
                                <div class="card-body py-4 px-4">
                                    <div
                                        class="d-flex flex-column flex-md-row align-items-md-center justify-content-between">
                                        <div class="mb-2 mb-md-0">
                                            <h4 class="mb-1 text-primary fw-semibold">Casting Entry</h4>
                                            <p class="text-muted mb-0">Fill out the form below to add casting entry</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="d-flex justify-content-center min-vh-100 bg-light">
                            <div class="col-md-12">
                                <div class="card shadow">
                                    <div class="card-body">
                                        <form action="<?php echo e(route('casting.store')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>

                                            <?php for($i = 1; $i <= 3; $i++): ?>
                                                <h5 class="text-secondary">Machine <?php echo e($i); ?></h5>
                                                <div class="row mb-4">
                                                    <div class="col-md-4">
                                                        <label class="form-label">Company</label>
                                                        <select name="casting[<?php echo e($i); ?>][company_id]" class="form-select"
                                                            required>
                                                            <option value="">Select Company</option>
                                                            <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($company->id); ?>"><?php echo e($company->name); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <label class="form-label">Tool Type</label>
                                                        <select name="casting[<?php echo e($i); ?>][tool_type_id]" class="form-select"
                                                            required>
                                                            <option value="">Select Tool</option>
                                                            <?php $__currentLoopData = $tools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tool): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($tool->id); ?>"><?php echo e($tool->name); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <label class="form-label">Quantity</label>
                                                        <input type="number" name="casting[<?php echo e($i); ?>][quantity]"
                                                            class="form-control" min="1" required>
                                                    </div>
                                                </div>
                                            <?php endfor; ?>

                                            <div class="d-grid">
                                                <button type="submit" class="btn btn-primary">Submit Casting
                                                    Entry</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>

                                <div class="card shadow mt-4">
                                    <div class="card-body">
                                        <h5 class="mb-3 text-primary">Casting Records</h5>
                                        <div class="table-responsive">
                                            <table class="table table-bordered table-striped align-middle">
                                                <thead class="table-primary">
                                                    <tr>
                                                        <th>Sr No</th>
                                                        <th>Machine Number</th>
                                                        <th>Company</th>
                                                        <th>Tool</th>
                                                        <th>Quantity</th>
                                                        <th>Created At</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__empty_1 = true; $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                        <tr>
                                                            <td><?php echo e($records->firstItem() + $index); ?></td>
                                                            <td><?php echo e($record->machine_no); ?></td>
                                                            <td><?php echo e($record->company->name); ?></td>
                                                            <td><?php echo e($record->tool->name); ?></td>
                                                            <td><?php echo e($record->quantity); ?></td>
                                                            <td><?php echo e($record->created_at->format('d M Y')); ?></td>
                                                            <td>
                                                                <form action="<?php echo e(route('casting.destroy', $record->id)); ?>"
                                                                    method="POST"
                                                                    onsubmit="return confirm('Are you sure?');">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('DELETE'); ?>
                                                                    <button type="submit"
                                                                        class="btn btn-danger btn-sm">Delete</button>
                                                                </form>
                                                            </td>

                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                        <tr>
                                                            <td colspan="6" class="text-center">No records found</td>
                                                        </tr>
                                                    <?php endif; ?>
                                            </table>
                                            <div class="d-flex justify-content-end mt-3">
                                                <?php echo $records->links('pagination::bootstrap-5'); ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="<?php echo e(asset('js/jquery.min.js')); ?>"> </script>
<script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"> </script>
<script src="<?php echo e(asset('js/default-assets/setting.js')); ?>"> </script>
<script src="<?php echo e(asset('js/default-assets/scrool-bar.js')); ?>"> </script>
<script src="<?php echo e(asset('js/todo-list.js')); ?>"> </script>
<script src="<?php echo e(asset('js/default-assets/active.js')); ?>"> </script>
<script src="<?php echo e(asset('js/apexcharts.min.js')); ?>"> </script>
<script src="<?php echo e(asset('js/dashboard-custom-sass.js')); ?>"> </script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script><?php /**PATH C:\xampp\htdocs\industry\resources\views/Production/casting.blade.php ENDPATH**/ ?>