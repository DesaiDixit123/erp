  <link rel="icon" href="<?php echo e(asset('img/core-img/favicon.ico')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/animate.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style.css')); ?>">



<!-- Preloader -->
<div id="preloader">
    <div class="scene">
        <div class="cube-wrapper">
            <div class="cube">
                <div class="cube-faces">
                    <div class="cube-face shadow"></div>
                    <div class="cube-face bottom"></div>
                    <div class="cube-face top"></div>
                    <div class="cube-face left"></div>
                    <div class="cube-face right"></div>
                    <div class="cube-face back"></div>
                    <div class="cube-face front"></div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /Preloader -->

<div class="flapt-page-wrapper">
    <!-- Sidemenu Area -->
    <div class="flapt-sidemenu-wrapper">
     <?php echo $__env->make('layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    <div class="flapt-page-content">
        <?php echo $__env->make('layouts.topbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <!-- Main Content Area -->
        <div class="main-content">
            <div class="content-wraper-area">
                <!-- Start Content-->
                <div class="container-fluid">
                    <div class="row g-4">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body card-breadcrumb">
                                    <div class="page-title-box d-flex align-items-center justify-content-between">
                                        <h4 class="mb-0">Dashboard User Info</h4>
                                       
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-body">
                                    <div class="pt-4 pb-4 border-bottom">
                                        <div class="personal-info-area">
                                            <!-- <p class="mb-2 text-dark">Dashboard User Info:</p> -->
                                            <ul class="list-group personal-data">
                                                <li class="list-group-item">
                                                    <div class="d-flex flex-wrap align-items-center">
                                                        <div class="me-2"> Name : </div>
                                                        <span class="text-muted"><?php echo e($employee->name); ?></span>
                                                    </div>
                                                </li>
                                                <li class="list-group-item">
                                                    <div class="d-flex flex-wrap align-items-center">
                                                        <div class="me-2"> Email : </div>
                                                        <span class="text-muted"><?php echo e($employee->email); ?></span>
                                                    </div>
                                                </li>
                                                <li class="list-group-item">
                                                    <div class="d-flex flex-wrap align-items-center">
                                                        <div class="me-2"> Phone : </div>
                                                        <span class="text-muted"><?php echo e($employee->phone ?? 'N/A'); ?></span>
                                                    </div>
                                                </li>
                                                <li class="list-group-item">
                                                    <div class="d-flex flex-wrap align-items-center">
                                                        <div class="me-2"> Designation : </div>
                                                        <span
                                                            class="text-muted"><?php echo e($employee->user_type ?? 'N/A'); ?></span>
                                                    </div>
                                                </li>
                                                <li class="list-group-item">
                                                    <div class="d-flex flex-wrap align-items-center">
                                                        <div class="me-2"> Status : </div>
                                                        <span class="text-muted"><?php echo e($employee->user_status); ?></span>
                                                    </div>
                                                </li>
                                                <li class="list-group-item">
                                                    <div class="d-flex flex-wrap align-items-center">
                                                        <div class="me-2"> Address : </div>
                                                        <span class="text-muted"><?php echo e($employee->address); ?></span>
                                                    </div>
                                                </li>
                                                <li class="list-group-item">
                                                    <div class="d-flex flex-wrap align-items-center">
                                                        <div class="me-2">Pan Card :</div>
                                                        <?php if($employee->pan_image): ?>
                                                            <img src="<?php echo e(asset('storage/' . $employee->pan_image)); ?>"
                                                                alt="Pan Card" style="max-width: 100px; height: auto;">
                                                        <?php else: ?>
                                                            <span class="text-muted">Not uploaded</span>
                                                        <?php endif; ?>
                                                    </div>
                                                </li>

                                                <li class="list-group-item">
                                                    <div class="d-flex flex-wrap align-items-center">
                                                        <div class="me-2">Aadhar Card :</div>
                                                        <?php if($employee->adhar_image): ?>
                     <img src="<?php echo e(asset('storage/' . $employee->adhar_image)); ?>" alt="Aadhar Card" style="max-width: 100px; height: auto;">

                                                        <?php else: ?>
                                                            <span class="text-muted">Not uploaded</span>
                                                        <?php endif; ?>
                                                    </div>
                                                </li>

                                                
                                                <?php if(!empty($employee->age)): ?>
                                                    <li class="list-group-item">
                                                        <div class="d-flex flex-wrap align-items-center">
                                                            <div class="me-2"> Age : </div>
                                                            <span class="text-muted"><?php echo e($employee->age); ?></span>
                                                        </div>
                                                    </li>
                                                <?php endif; ?>

                                                <?php if(!empty($employee->experience)): ?>
                                                    <li class="list-group-item">
                                                        <div class="d-flex flex-wrap align-items-center">
                                                            <div class="me-2"> Experience : </div>
                                                            <span class="text-muted"><?php echo e($employee->experience); ?></span>
                                                        </div>
                                                    </li>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </div>
                                </div> <!-- card-body -->
                            </div> <!-- card -->
                        </div> <!-- col -->
                    </div> <!-- row -->
                </div> <!-- container-fluid -->
            </div> <!-- content-wraper-area -->
        </div> <!-- main-content -->
    </div> <!-- flapt-page-content -->
</div> <!-- flapt-page-wrapper -->


<script src="<?php echo e(asset('js/jquery.min.js')); ?>"> </script>
<script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"> </script>
<script src="<?php echo e(asset('js/default-assets/setting.js')); ?>"> </script>
<script src="<?php echo e(asset('js/default-assets/scrool-bar.js')); ?>"> </script>
<script src="<?php echo e(asset('js/todo-list.js')); ?>"> </script>
<script src="<?php echo e(asset('js/default-assets/active.js')); ?>"> </script>
<script src="<?php echo e(asset('js/apexcharts.min.js')); ?>"> </script>
<script src="<?php echo e(asset('js/dashboard-custom-sass.js')); ?>"> </script>
<?php /**PATH C:\xampp\htdocs\industry\resources\views/Employees/ViewEmployee.blade.php ENDPATH**/ ?>