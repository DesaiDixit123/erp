<link rel="icon" href="{{ asset('img/core-img/favicon.ico') }}">
<link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">
<link rel="stylesheet" href="{{ asset('css/animate.css') }}">
<link rel="stylesheet" href="{{ asset('style.css') }}">

<div id="preloader">
    <div class="scene">
        <div class="cube-wrapper">
            <div class="cube">
                <div class="cube-faces">
                    <div class="cube-face shadow"></div>
                    <div class="cube-face bottom"></div>
                    <div class="cube-face top"></div>
                    <div class="cube-face left"></div>
                    <div class="cube-face right"></div>
                    <div class="cube-face back"></div>
                    <div class="cube-face front"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="flapt-page-wrapper">
    <div class="flapt-sidemenu-wrapper">
        @include('layouts.sidebar')
    </div>

    <div class="flapt-page-content">
        @include('layouts.topbar')

        @if(session('success'))
            <div class="toast-container position-fixed top-0 end-0 p-3" style="z-index: 9999;">
                <div class="toast align-items-center text-bg-success border-0 show" role="alert">
                    <div class="d-flex">
                        <div class="toast-body">
                            {{ session('success') }}
                        </div>
                        <button type="button" class="btn-close btn-close-white me-2 m-auto"
                            data-bs-dismiss="toast"></button>
                    </div>
                </div>
            </div>
        @endif

        @if($errors->any())
            <div class="toast-container position-fixed top-0 end-0 p-3" style="z-index: 9999;">
                <div class="toast align-items-center text-bg-danger border-0 show" role="alert">
                    <div class="d-flex">
                        <div class="toast-body">
                            @foreach ($errors->all() as $error)
                                {{ $error }}<br>
                            @endforeach
                        </div>
                        <button type="button" class="btn-close btn-close-white me-2 m-auto"
                            data-bs-dismiss="toast"></button>
                    </div>
                </div>
            </div>
        @endif

        <div class="main-content">
            <div class="content-wraper-area">
                <div class="container-fluid">
                    <div class="row g-4">
                        <div class="col-12">
                            <div class="card shadow-sm border-0">
                                <div class="card-body py-4 px-4">
                                    <div
                                        class="d-flex flex-column flex-md-row align-items-md-center justify-content-between">
                                        <div class="mb-2 mb-md-0">
                                            <h4 class="mb-1 text-primary fw-semibold">Casting Entry</h4>
                                            <p class="text-muted mb-0">Fill out the form below to add casting entry</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="d-flex justify-content-center min-vh-100 bg-light">
                            <div class="col-md-12">
                                <div class="card shadow">
                                    <div class="card-body">
                                        <form action="{{ route('casting.store') }}" method="POST">
                                            @csrf

                                            @for ($i = 1; $i <= 3; $i++)
                                                <h5 class="text-secondary">Machine {{ $i }}</h5>
                                                <div class="row mb-4">
                                                    <div class="col-md-4">
                                                        <label class="form-label">Company</label>
                                                        <select name="casting[{{ $i }}][company_id]" class="form-select"
                                                            required>
                                                            <option value="">Select Company</option>
                                                            @foreach($companies as $company)
                                                                <option value="{{ $company->id }}">{{ $company->name }}</option>
                                                            @endforeach
                                                        </select>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <label class="form-label">Tool Type</label>
                                                        <select name="casting[{{ $i }}][tool_type_id]" class="form-select"
                                                            required>
                                                            <option value="">Select Tool</option>
                                                            @foreach($tools as $tool)
                                                                <option value="{{ $tool->id }}">{{ $tool->name }}</option>
                                                            @endforeach
                                                        </select>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <label class="form-label">Quantity</label>
                                                        <input type="number" name="casting[{{ $i }}][quantity]"
                                                            class="form-control" min="1" required>
                                                    </div>
                                                </div>
                                            @endfor

                                            <div class="d-grid">
                                                <button type="submit" class="btn btn-primary">Submit Casting
                                                    Entry</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>

                                <div class="card shadow mt-4">
                                    <div class="card-body">
                                        <h5 class="mb-3 text-primary">Casting Records</h5>
                                        <div class="table-responsive">
                                            <table class="table table-bordered table-striped align-middle">
                                                <thead class="table-primary">
                                                    <tr>
                                                        <th>Sr No</th>
                                                        <th>Machine Number</th>
                                                        <th>Company</th>
                                                        <th>Tool</th>
                                                        <th>Quantity</th>
                                                        <th>Created At</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @forelse($records as $index => $record)
                                                        <tr>
                                                            <td>{{ $records->firstItem() + $index }}</td>
                                                            <td>{{ $record->machine_no }}</td>
                                                            <td>{{ $record->company->name }}</td>
                                                            <td>{{ $record->tool->name }}</td>
                                                            <td>{{ $record->quantity }}</td>
                                                            <td>{{ $record->created_at->format('d M Y') }}</td>
                                                            <td>
                                                                <form action="{{ route('casting.destroy', $record->id) }}"
                                                                    method="POST"
                                                                    onsubmit="return confirm('Are you sure?');">
                                                                    @csrf
                                                                    @method('DELETE')
                                                                    <button type="submit"
                                                                        class="btn btn-danger btn-sm">Delete</button>
                                                                </form>
                                                            </td>

                                                        </tr>
                                                    @empty
                                                        <tr>
                                                            <td colspan="6" class="text-center">No records found</td>
                                                        </tr>
                                                    @endforelse
                                            </table>
                                            <div class="d-flex justify-content-end mt-3">
                                                {!! $records->links('pagination::bootstrap-5') !!}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="{{ asset('js/jquery.min.js') }}"> </script>
<script src="{{ asset('js/bootstrap.bundle.min.js') }}"> </script>
<script src="{{ asset('js/default-assets/setting.js') }}"> </script>
<script src="{{ asset('js/default-assets/scrool-bar.js') }}"> </script>
<script src="{{ asset('js/todo-list.js') }}"> </script>
<script src="{{ asset('js/default-assets/active.js') }}"> </script>
<script src="{{ asset('js/apexcharts.min.js') }}"> </script>
<script src="{{ asset('js/dashboard-custom-sass.js') }}"> </script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>