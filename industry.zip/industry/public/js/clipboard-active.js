var clipboard = new ClipboardJS(".btn");
clipboard.on("success", function (o) {
    console.log(o);
}),
    clipboard.on("error", function (o) {
        console.log(o);
    });
