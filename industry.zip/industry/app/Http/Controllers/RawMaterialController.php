<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\RawMaterialType;
class RawMaterialController extends Controller
{
    public function index()
    {
        $types = RawMaterialType::paginate(10);
        return view('raw_material.type', compact('types'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => 'required|string|unique:raw_material_types,name',
        ]);

        RawMaterialType::create($data);

        return redirect()->route('raw_material.index')->with('success', 'Raw material type added!');
    }


    public function edit($id)
    {
        $type = RawMaterialType::findOrFail($id);
        return view('raw_material.edit', compact('type'));
    }

    public function update(Request $request, $id)
    {
        $data = $request->validate([
            'name' => 'required|string|unique:raw_material_types,name,' . $id,
        ]);

        $type = RawMaterialType::findOrFail($id);
        $type->update($data);

        return redirect()->route('raw_material.index')->with('success', 'Raw material type updated!');
    }

    public function destroy($id)
    {
        $type = RawMaterialType::findOrFail($id);
        $type->delete();

        return redirect()->route('raw_material.index')->with('success', 'Raw material type deleted!');
    }
}
