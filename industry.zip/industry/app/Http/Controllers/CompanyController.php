<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Company;
use Illuminate\Support\Facades\Storage;
class CompanyController extends Controller
{

    public function index(){
        $companies = Company::orderBy('created_at', 'desc')->paginate(10);
        return view("Company.company",compact('companies'));
    }
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);

        $company = new Company();
        $company->name = $request->name;

        if ($request->hasFile('image')) {
            $imagePath = $request->file('image')->store('companies', 'public');
            $company->image = $imagePath;
        }

        $company->save();

        return back()->with('success', 'Company created successfully!');
    }


       public function edit($id)
    {
        $companies = Company::findOrFail($id);
        return view('Company.edit', compact('companies'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
              'phone_number' => 'nullable|string|max:20',
        ]);

        $company = Company::findOrFail($id);

        if ($request->hasFile('image')) {
            // Delete old image
            if ($company->image && Storage::disk('public')->exists($company->image)) {
                Storage::disk('public')->delete($company->image);
            }

            $imagePath = $request->file('image')->store('companies', 'public');
            $company->image = $imagePath;
        }

        $company->name = $request->name;
       
        $company->save();

        return redirect()->route('companies.index')->with('success', 'Company updated successfully.');
    }



       public function destroy($id)
    {
        $company = Company::findOrFail($id);

        // Delete image
        if ($company->image && Storage::disk('public')->exists($company->image)) {
            Storage::disk('public')->delete($company->image);
        }

        $company->delete();

        return redirect()->route('companies.index')->with('success', 'Company deleted successfully.');
    }
}
