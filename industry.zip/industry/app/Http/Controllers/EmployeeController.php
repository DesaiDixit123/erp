<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;
use App\Models\Employee;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
class EmployeeController extends Controller
{
  public function index()
    {

        return view('Employees.AddEmployee');
    }

        public function store(Request $request)
    {
        $validatedData = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:employees,email',
            'phone' => [
                'required',
                'regex:/^[0-9]{10}$/',
            ],
            'address' => 'nullable|string',
            'password' => 'required|string|min:6',
            'password_confirmation' => 'required|string|min:6',
            'user_type' => 'required|in:Admin,Operator', // ✅ Validate user type
            'avatar' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
            'adhar_image' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
            'pan_image' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
        ], [
            'phone.regex' => 'Phone number must be exactly 10 digits.',
            'email.unique' => 'This email is already registered.',
        ]);

        if ($request->password !== $request->password_confirmation) {
            return response()->json([
                'errors' => [
                    'password' => ['Password and Confirm Password do not match.']
                ]
            ], 422);
        }

        // ✅ File Uploads
        if ($request->hasFile('avatar')) {
            $validatedData['avatar'] = $request->file('avatar')->store('avatars', 'public');
        }

        if ($request->hasFile('adhar_image')) {
            $validatedData['adhar_image'] = $request->file('adhar_image')->store('adhar_images', 'public');
        }

        if ($request->hasFile('pan_image')) {
            $validatedData['pan_image'] = $request->file('pan_image')->store('pan_images', 'public');
        }

        // ✅ Hash the password
        $validatedData['password'] = Hash::make($validatedData['password']);

        // ✅ Create Employee with user_type
        $employee = Employee::create($validatedData);
        // ✅ Redirect based on user_type
        if ($employee->user_type === 'Admin') {
            return response()->json([
                'message' => 'Admin added successfully!',
                'redirect' => route('admin.list')
            ]);
        } else {
            return response()->json([
                'message' => 'Operator added successfully!',
                'redirect' => route('operator.list')
            ]);
        }
    }


     public function AdminList()
    {
        $admins = Employee::where('user_type', 'Admin')
            ->orderBy('created_at', 'desc')
            ->paginate(10);

        return view('Employees.AdminList', compact('admins'));
    }


    public function OperatorList()
    {
        $employees = Employee::where('user_type', 'Operator')
            ->orderBy('created_at', 'desc')
            ->paginate(10);

        return view('Employees.EmployeeList', compact('employees'));
    }


      public function show($id)
    {
        $employee = Employee::findOrFail($id);
        return view('Employees.ViewEmployee', compact('employee'));
    }

    // Edit form
    public function editEmployee($id)
    {
        $employee = Employee::findOrFail($id);

        // Optional: You can conditionally load a different view if required
        if ($employee->user_type === 'Admin') {
            return view('Employees.EditAdmin', compact('employee'));
        } else {
            return view('Employees.EditEmployee', compact('employee'));
        }
    }


    // Update employee
    public function update(Request $request, $id)
    {
        $employee = Employee::findOrFail($id);

        $validatedData = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:employees,email,' . $employee->id,
            'user_type' => 'required|in:Admin,Operator',
            'phone' => 'required|string|max:20',
            'address' => 'nullable|string',
            'avatar' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
            'adhar_image' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
            'pan_image' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
        ]);

        if ($request->hasFile('avatar')) {
            $validatedData['avatar'] = $request->file('avatar')->store('avatars', 'public');
        }

        if ($request->hasFile('adhar_image')) {
            $validatedData['adhar_image'] = $request->file('adhar_image')->store('adhar_images', 'public');
        }

        if ($request->hasFile('pan_image')) {
            $validatedData['pan_image'] = $request->file('pan_image')->store('pan_images', 'public');
        }

        $employee->update($validatedData);

        // ✅ Redirect based on user_type
        if ($employee->user_type === 'Admin') {
            return redirect()->route('admin.list')->with('success', 'Admin updated successfully!');
        } else {
            return redirect()->route('operator.list')->with('success', 'Operator updated successfully!');
        }
    }

    // Delete employee
    public function adminDestroy($id)
    {
        $employee = Employee::findOrFail($id);
        $employee->delete();

        return redirect()->route('admin.list')->with('success', 'Admin deleted successfully!');
    }
    public function operatorDestroy($id)
    {
        $employee = Employee::findOrFail($id);
        $employee->delete();

        return redirect()->route('operator.list')->with('success', 'Operator deleted successfully!');
    }

    public function activate($id)
    {
        $employee = Employee::findOrFail($id);
        $employee->user_status = 'Active';
        $employee->save();

        return back()->with('success', 'User activated successfully!');
    }
    public function deactivate($id)
    {
        $employee = Employee::findOrFail($id);
        $employee->user_status = 'inactive';
        $employee->save();

        return back()->with('success', 'User deactivated successfully!');
    }


public function myProfile()
{
    // ✅ Check if Admin is logged in
    if (session('admin_logged_in')) {
        $admin = (object)[
            'id' => session('admin_id'),
            'name' => session('admin_name'),
            'email' => session('admin_email'),
            'avatar' => session('admin_image') ?? null,
            'phone' => '', // optional: set if needed
            'address' => '', // optional: set if needed
            'user_type' => 'Admin',
        ];

        return view('Employees.OperatorMyProfile', ['employee' => $admin, 'role' => 'admin']);
    }

    // ✅ Check if Employee is logged in
    if (session('employee_logged_in')) {
        $employee = Employee::find(session('employee_id'));

        if (!$employee) {
            return redirect()->route('login')->with('error', 'User not found.');
        }

        return view('Employees.OperatorMyProfile', ['employee' => $employee, 'role' => 'employee']);
    }

    // ❌ If not logged in
    return redirect()->route('login')->with('error', 'Please log in to view your profile.');
}


public function updateMyProfile(Request $request)
{
    // ✅ If Admin
    if (session('admin_logged_in')) {
        $validatedData = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email',
            'avatar' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
        ]);

        // Handle avatar upload
        if ($request->hasFile('avatar')) {
            $validatedData['avatar'] = $request->file('avatar')->store('avatars', 'public');
            session(['admin_image' => $validatedData['avatar']]);
        }

        session(['admin_name' => $validatedData['name']]);
        session(['admin_email' => $validatedData['email']]);

        return redirect()->back()->with('success', 'Admin profile updated successfully!');
    }

    // ✅ If Employee
    if (session('employee_logged_in')) {
        $employee = Employee::find(session('employee_id'));

        $validatedData = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:employees,email,' . $employee->id,
            'phone' => 'required|string|max:20',
            'address' => 'nullable|string',
            'avatar' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
            'user_type' => 'required|in:Admin,Operator',
        ]);

        if ($request->hasFile('avatar')) {
            if ($employee->avatar && Storage::disk('public')->exists($employee->avatar)) {
                Storage::disk('public')->delete($employee->avatar);
            }
            $validatedData['avatar'] = $request->file('avatar')->store('avatars', 'public');
        }

        $employee->update($validatedData);

        return redirect()->back()->with('success', 'Employee profile updated successfully!');
    }

    return redirect()->route('login')->with('error', 'Unauthorized action.');
}

public function changePassword(Request $request)
{
    $request->validate([
        'current_password' => 'required',
        'new_password' => 'required|min:6|confirmed',
    ]);

    // ✅ If Admin
    if (session('admin_logged_in')) {
        $adminEmail = 'admin@gmail.com';
        $adminPassword = 'admin123';

        if (
            session('admin_email') === $adminEmail &&
            $request->current_password === $adminPassword
        ) {
            // 🔒 Hardcoded password cannot be changed here
            return back()->with('error', 'Admin password is static and cannot be changed.');
        }

        return back()->with('error', 'Unauthorized access.');
    }

    // ✅ If Employee
    if (session('employee_logged_in')) {
        $employee = Employee::find(session('employee_id'));

        if (!$employee || !Hash::check($request->current_password, $employee->password)) {
            return back()->with('error', 'Current password is incorrect.');
        }

        $employee->password = Hash::make($request->new_password);
        $employee->save();

        return back()->with('success', 'Password updated successfully.');
    }

    return redirect()->route('login')->with('error', 'Unauthorized access.');
}


public function employeeDestroy($id = null)
{
    if (session('admin_logged_in')) {
        session()->flush();
        return redirect()->route('login')->with('success', 'Admin account logged out successfully.');
    }

    if (session('employee_logged_in')) {
        $employee = Employee::findOrFail(session('employee_id'));
        $employee->delete();
        session()->flush();
        return redirect()->route('login')->with('success', 'Your account has been deleted successfully.');
    }

    return redirect()->route('login')->with('error', 'Unauthorized action.');
}

}
