<?php

namespace App\Http\Controllers;

use App\Models\CastingRecord;
use Illuminate\Http\Request;
use App\Models\Company;
use App\Models\Tool;


class CastingRecordController extends Controller
{
    public function index()
    {
        $companies = Company::all();
        $tools = Tool::all();
        $records = CastingRecord::with(['company', 'tool'])->paginate(10);

        return view('Production.casting', compact('companies', 'tools', 'records'));
    }

public function store(Request $request)
{
    $validated = $request->validate([
        'casting.*.company_id' => 'required|exists:companies,id',
        'casting.*.tool_type_id' => 'required|exists:tools,id',
        'casting.*.quantity' => 'required|integer|min:1',
    ]);

    foreach ($request->casting as $machine_no => $record) {
        CastingRecord::updateOrCreate(
            [
                'machine_no' => $machine_no,    
                'company_id' => $record['company_id'],
                'tool_type_id' => $record['tool_type_id'],
            ],
            ['quantity' => $record['quantity']]
        );
    }

    return redirect()->back()->with('success', 'Casting data saved successfully!');
}
 
public function destroy($id)
{
    $record = CastingRecord::findOrFail($id);
    $record->delete();

    return redirect()->back()->with('success', 'Casting record deleted successfully!');
}

}
