<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\adminAuth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;

use Illuminate\Support\Facades\Session;
class AdminAuthController extends Controller
{


    public function index()
    {



        return view('Admin.adminRegister');
    }
    public function adminLogin()
    {



        return view('Admin.adminLogin');
    }
    public function adminDashboard()
    {



        return view('dashboard.dashboard');
    }

    public function register(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|unique:admin_auth,email',
            'password' => 'required|string|min:6',
        ]);

        $user = adminAuth::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
        ]);

        return redirect('/login')->with('success', 'Registration successful. Please login.');
    }


    public function login(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required',
        ]);

        $user = adminAuth::where('email', $request->email)->first();

        if ($user && Hash::check($request->password, $user->password)) {
            // Set session manually
            session(['admin' => $user]);

            // Redirect to dashboard
            return redirect('/')->with('success', 'Login successful!');
        }

        return back()->with('error', 'Invalid credentials');
    }

     public function logout()
    {
        Session::flush();
        return redirect()->route('login')->with('success', 'Logged out successfully.');
    }

}
