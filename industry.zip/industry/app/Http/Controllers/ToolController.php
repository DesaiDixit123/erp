<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Tool;

use Illuminate\Support\Facades\Storage;
class ToolController extends Controller
{
   
    public function index(){
        $tools = Tool::orderBy('created_at', 'desc')->paginate(10);
        return view("Tools.tools",compact('tools'));
    }
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);

        $tool = new Tool();
        $tool->name = $request->name;

        if ($request->hasFile('image')) {
            $imagePath = $request->file('image')->store('tools', 'public');
            $tool->image = $imagePath;
        }

        $tool->save();

        return back()->with('success', 'Tool created successfully!');
    }


       public function edit($id)
    {
        $tools = Tool::findOrFail($id);
        return view('Tools.edit', compact('tools'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
              'phone_number' => 'nullable|string|max:20',
        ]);

        $tool = Tool::findOrFail($id);

        if ($request->hasFile('image')) {
            // Delete old image
            if ($tool->image && Storage::disk('public')->exists($tool->image)) {
                Storage::disk('public')->delete($tool->image);
            }

            $imagePath = $request->file('image')->store('tools', 'public');
            $tool->image = $imagePath;
        }

        $tool->name = $request->name;
       
        $tool->save();

        return redirect()->route('tools.index')->with('success', 'Tool updated successfully.');
    }



       public function destroy($id)
    {
        $tool = Tool::findOrFail($id);

        // Delete image
        if ($tool->image && Storage::disk('public')->exists($tool->image)) {
            Storage::disk('public')->delete($tool->image);
        }

        $tool->delete();

        return redirect()->route('tools.index')->with('success', 'Tool deleted successfully.');
    }
}
