<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CastingRecord extends Model
{
     protected $fillable = [
        'machine_no',
        'company_id',
        'tool_type_id',
        'quantity',
    ];

    public function company()
    {
        return $this->belongsTo(Company::class);
    }

public function tool()
{
    return $this->belongsTo(Tool::class, 'tool_type_id');
}

}
