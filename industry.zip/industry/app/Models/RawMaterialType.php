<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RawMaterialType extends Model
{
    protected $fillable = ['name'];

    public function available()
    {
        return $this->hasMany(AvailableRawMaterial::class);
    }

    public function consumable()
    {
        return $this->hasMany(ConsumableRawMaterial::class);
    }

}
