<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminAuthController;
use App\Http\Controllers\EmployeeController;
use App\Http\Controllers\CompanyController;
use App\Http\Controllers\ToolController;
use App\Http\Controllers\RawMaterialController;
use App\Http\Controllers\AvailableRawMaterialController;
use App\Http\Controllers\ConsumableRawMaterialController;
use App\Http\Controllers\CastingRecordController;

Route::get('/', function () {
    return redirect('/login');
});


Route::get('/admin-register', [AdminAuthController::class, 'index']);


Route::get('/login', [AdminAuthController::class, 'adminLogin']);
Route::post('/login', [AdminAuthController::class, 'login'])->name('login');

Route::post('/register', [AdminAuthController::class, 'register']);



Route::middleware(['admin'])->group(function () {
    Route::get('/', [AdminAuthController::class, 'adminDashboard'])->name('dashboard');
        Route::get('/logout', [AdminAuthController::class, 'logout'])->name('logout');
        Route::get('/add-employee', [EmployeeController::class, 'index'])->name('employee.create');
        Route::post('/employee', [EmployeeController::class, 'store'])->name('employee.store');





        Route::get('/company', [CompanyController::class, 'index'])->name('companies.index');
        Route::post('/company-store', [CompanyController::class, 'store'])->name('company.store');
Route::get('/company/{id}/edit', [CompanyController::class, 'edit'])->name('companies.edit');
Route::patch('/companies/{id}', [CompanyController::class, 'update'])->name('companies.update');
Route::delete('/companies/{id}', [CompanyController::class, 'destroy'])->name('companies.destroy');



        Route::get('/tools', [ToolController::class, 'index'])->name('tools.index');
        Route::post('/tool-store', [ToolController::class, 'store'])->name('tools.store');
Route::get('/tool/{id}/edit', [ToolController::class, 'edit'])->name('tools.edit');
Route::patch('/tools/{id}', [ToolController::class, 'update'])->name('tools.update');
Route::delete('/tools/{id}', [ToolController::class, 'destroy'])->name('tools.destroy');






        Route::get('/operator-list', [EmployeeController::class, 'OperatorList'])->name('operator.list');
Route::get('/admin-list', [EmployeeController::class, 'AdminList'])->name('admin.list');
Route::post('/employee/toggle-status/{id}', [EmployeeController::class, 'toggleStatus'])->name('employee.toggleStatus');


Route::post('/employee/activate/{id}', [EmployeeController::class, 'activate'])->name('employee.activate');
Route::post('/employee/deactivate/{id}', [EmployeeController::class, 'deactivate'])->name('employee.deactivate');
    Route::get('/employee/{id}', [EmployeeController::class, 'show'])->name('add-employee.show'); // View single employee
    Route::get('/employee/{id}/edit', [EmployeeController::class, 'editEmployee'])->name('add-employee.edit'); // Edit form
 
    Route::put('/employee/{id}', [EmployeeController::class, 'update'])->name('add-employee.update'); // Update employee
    Route::delete('/admin/{id}', [EmployeeController::class, 'adminDestroy'])->name('add-admin.destroy'); // Delete admin
    Route::delete('/operator/{id}', [EmployeeController::class, 'operatorDestroy'])->name('add-operator.destroy'); // Delete operator
     Route::get('/operator-my-profile', [EmployeeController::class, 'myProfile'])->name('profile.view');
    Route::post('/my-profile/update', [EmployeeController::class, 'updateMyProfile'])->name('profile.update');
Route::post('/employee/change-password', [EmployeeController::class, 'changePassword'])->name('employee.changePassword');
Route::delete('/employee/delete/{id}', [EmployeeController::class, 'employeeDestroy'])->name('employee.delete');
Route::delete('/admin/logout', [EmployeeController::class, 'employeeDestroy'])->name('admin.logout');





Route::get('/raw-material-type', [RawMaterialController::class, 'index'])->name('raw_material.index');
Route::post('/raw-material-type', [RawMaterialController::class, 'store'])->name('raw_material.store');
Route::get('/raw-material-type/{id}/edit', [RawMaterialController::class, 'edit'])->name('raw_material.edit');
Route::post('/raw-material-type/{id}/update', [RawMaterialController::class, 'update'])->name('raw_material.update');
Route::delete('/raw-material-type/{id}', [RawMaterialController::class, 'destroy'])->name('raw_material.destroy');
Route::get('/available-raw-material-type', [AvailableRawMaterialController::class, 'index'])->name('available.index');
Route::post('/available', [AvailableRawMaterialController::class, 'store'])->name('available.store');
Route::get('/available-raw-material-type/{id}/edit', [AvailableRawMaterialController::class, 'edit'])->name('available.edit');
Route::put('/available/{id}', [AvailableRawMaterialController::class, 'update'])->name('available.update');
Route::delete('/available/{id}', [AvailableRawMaterialController::class, 'destroy'])->name('available.destroy');
Route::get('/consumable-raw-material', [ConsumableRawMaterialController::class, 'index'])->name('consumable.index');
Route::post('/consumable', [ConsumableRawMaterialController::class, 'store'])->name('consumable.store');
Route::get('/consumable-raw-material-type/{id}/edit', [ConsumableRawMaterialController::class, 'edit'])->name('consumable.edit');
Route::put('/consumable/{id}', [ConsumableRawMaterialController::class, 'update'])->name('consumable.update');
Route::delete('/consumable/{id}', [ConsumableRawMaterialController::class, 'destroy'])->name('consumable.destroy');





Route::get('/casting', [CastingRecordController::class, 'index'])->name('casting.index');
Route::post('/casting', [CastingRecordController::class, 'store'])->name('casting.store');
Route::delete('/casting/{id}', [CastingRecordController::class, 'destroy'])->name('casting.destroy');

});
